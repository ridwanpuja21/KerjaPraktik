<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

  public function index()
  {

    $this->form_validation->set_rules('username', 'Username', 'trim|required');
    $this->form_validation->set_rules('password', 'Password', 'trim|required');

    if ($this->form_validation->run() == false) {
      $data['login'] = '0';
      $tittle['title'] = 'Login Page';
      $this->load->view('templates/header', $tittle);
      $this->load->view('auth/login');
      $this->load->view('templates/footer');
    } else {
      // validasi lolos
      $this->_login();
    }
  }

  private function _login()
  {
    $username = $this->input->post('username');
    $password = $this->input->post('password');

    $user = $this->db->get_where('tb_user', ['username' => $username])->row_array();

    // jika usernya ada pada database
    if ($user) {
      // cek password
      if ($password == $user['password']) {
        $data = [
          'username' => $user['username'],
          'id_login' => $user['id_login']
        ];
        $this->session->set_userdata($data);
        //  $auth = $this->Auth_model->login();
        redirect('administrator/dashboard');
      } else {
        $this->session->set_flashdata('login', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong>Maaf!</strong> Password yang anda masukkan salah.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        </div>');
        redirect('auth');
      }
    } else {
      $this->session->set_flashdata('login', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
      <strong>Maaf!</strong> Username yang anda masukkan salah.
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
      </div>');
      redirect('auth');
    }
  }

  public function logout()
  {
    $this->session->unset_userdata('username');
    $this->session->unset_userdata('id_login');

    $this->session->set_flashdata('login', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
      <strong>Sampai Jumpa Kembali!</strong> Logout berhasil dilakukan.
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>');
    redirect('auth');
  }
}
