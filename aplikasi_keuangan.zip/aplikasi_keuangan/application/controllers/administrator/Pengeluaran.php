<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pengeluaran extends CI_Controller
{

  public function __construct()
  {
    parent::__construct();
    if ($this->session->userdata('username') == null) {
      $this->session->set_flashdata('login', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
			<strong>Maaf!</strong> Anda belum Login.
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			</div>');
      redirect('auth');
    }
  }
  public function index()
  {
    $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
    $this->session->set_flashdata('dashboard', null);
    $this->session->set_flashdata('pemasukan', null);
    $data['pengeluaran'] = $this->Pengeluaran_model->tampil()->result();
    $tittle['title'] = 'Menu Pengeluaran';
    $this->load->view('templates/header', $tittle);
    $this->load->view('templates/sidebar', $data);
    $this->load->view('administrator/pengeluaran', $data);
    $this->load->view('templates/footer');
  }

  public function tambah()
  {
    $data['jml1'] = $this->Pengeluaran_model->jml1()->result();
    $data['jml2'] = $this->Pengeluaran_model->jml2()->result();
    foreach ($data['jml1'] as $jm1) {
    }
    foreach ($data['jml2'] as $jm2) {
    }
    $this->form_validation->set_rules('tanggal', 'Tanggal', 'trim|required');
    $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'trim|required');
    $this->form_validation->set_rules('nominal', 'Nominal', 'trim|required');

    if ($this->form_validation->run() == false) {
      $this->session->set_flashdata('pengeluaran', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong>Tambah Data Gagal!</strong> Data harus diisi semua.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        </div>');
      redirect('administrator/pengeluaran');
    } else {
      $saldo = $jm1->jml_pemasukan - $jm2->jml_pengeluaran;
      $tanggal    = $this->input->POST('tanggal');
      $deskripsi  = $this->input->POST('deskripsi');
      $nominal    = $this->input->POST('nominal');
      $id_login   = $this->session->userdata('id_login');

      if ($saldo >= $nominal) {
        $data = array(
          'tanggal'     => $tanggal,
          'deskripsi'   => $deskripsi,
          'nominal'     => $nominal,
          'id_login'    => $id_login,
        );
        $this->Pengeluaran_model->tambah($data, 'tb_pengeluaran');
        $this->session->set_flashdata('pengeluaran', '<div class="alert alert-dark alert-dismissible fade show" role="alert">
          <strong>Tambah Data Berhasil!</strong> Silahkan cek kembali data yang telah anda masukkan sesuai atau tidak.
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
          </div>');
        redirect('administrator/pengeluaran');
      } else {
        $this->session->set_flashdata('pengeluaran', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong>Tambah Data Gagal!</strong> Pengeluaran melebihi saldo yang tersedia.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        </div>');
        redirect('administrator/pengeluaran');
      }
    }
  }

  public function ubah()
  {
    $tambah = $this->input->POST('tambah');;
    $data['jml1'] = $this->Pengeluaran_model->jml1()->result();
    $data['jml2'] = $this->Pengeluaran_model->jml2()->result();
    foreach ($data['jml1'] as $jm1) {
    }
    foreach ($data['jml2'] as $jm2) {
    }
    foreach ($data['pengeluaran'] as $pnl) {
    }
    $this->form_validation->set_rules('tanggal', 'Tanggal', 'trim|required');
    $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'trim|required');
    $this->form_validation->set_rules('nominal', 'Nominal', 'trim|required');

    if ($this->form_validation->run() == false) {
      $this->session->set_flashdata('pengeluaran', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong>Ubah Data Gagal!</strong> Data harus diisi semua.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        </div>');
      redirect('administrator/pengeluaran');
    } else {
      $saldo = $jm1->jml_pemasukan - $jm2->jml_pengeluaran;
      $id         = $this->input->POST('id');
      $tanggal    = $this->input->POST('tanggal');
      $deskripsi  = $this->input->POST('deskripsi');
      $nominal    = $this->input->POST('nominal');
      $id_login   = $this->session->userdata('id_login');

      if ($saldo + $tambah >= $nominal) {
        $data = array(
          'tanggal'     => $tanggal,
          'deskripsi'   => $deskripsi,
          'nominal'     => $nominal,
          'id_login'    => $id_login,
        );

        $where = array(
          'id_pengeluaran' => $id
        );

        $this->Pengeluaran_model->ubah($where, $data, 'tb_pengeluaran');
        $this->session->set_flashdata('pengeluaran', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Data Berhasil Diubah!</strong> Silahkan cek kembali data yang telah anda ubah sesuai atau tidak.
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
            </div>');
        redirect('administrator/pengeluaran');
      } else {
        $this->session->set_flashdata('pengeluaran', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong>Ubah Data Gagal!</strong> Nominal pengeluaran lebih besar dari saldo.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        </div>');
        redirect('administrator/pengeluaran');
      }
    }
  }

  public function hapus()
  {
    $id         = $this->input->POST('id');
    $where      = array('id_pengeluaran' => $id);
    $this->Pengeluaran_model->hapus($where, 'tb_pengeluaran');
    $this->session->set_flashdata('pengeluaran', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Data Berhasil Dihapus!</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        </div>');
    redirect('administrator/pengeluaran');
  }
}
