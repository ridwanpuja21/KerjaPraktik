<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pemasukan extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    if ($this->session->userdata('username') == null) {
      $this->session->set_flashdata('login', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
			<strong>Maaf!</strong> Anda belum Login.
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			</div>');
      redirect('auth');
    }
  }

  public function index()
  {
    $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
    $this->session->set_flashdata('dashboard', null);
    $this->session->set_flashdata('pengeluaran', null);
    $data['pemasukan'] = $this->Pemasukan_model->tampil()->result();
    $tittle['title'] = 'Menu Pemasukan';
    $this->load->view('templates/header', $tittle);
    $this->load->view('templates/sidebar', $data);
    $this->load->view('administrator/pemasukan', $data);
    $this->load->view('templates/footer');
  }

  public function tambah()
  {
    $this->form_validation->set_rules('tanggal', 'Tanggal', 'trim|required');
    $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'trim|required');
    $this->form_validation->set_rules('nominal', 'Nominal', 'trim|required');

    if ($this->form_validation->run() == false) {
      $this->session->set_flashdata('pemasukan', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong>Tambah Data Gagal!</strong> Semua data harus diisi.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        </div>');
      redirect('administrator/pemasukan/index');
    } else {
      $tanggal    = $this->input->POST('tanggal');
      $deskripsi  = $this->input->POST('deskripsi');
      $nominal    = $this->input->POST('nominal');
      $id_login   = $this->session->userdata('id_login');

      $data = array(
        'tanggal'     => $tanggal,
        'deskripsi'   => $deskripsi,
        'nominal'     => $nominal,
        'id_login'    => $id_login,
      );

      $this->Pemasukan_model->tambah($data, 'tb_pemasukan');
      $this->session->set_flashdata('pemasukan', '<div class="alert alert-dark alert-dismissible fade show" role="alert">
        <strong>Tambah Data Berhasil!</strong> Silahkan cek kembali data yang telah anda masukkan sesuai atau tidak.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        </div>');
      redirect('administrator/pemasukan/index');
    }
  }

  public function ubah()
  {
    $this->form_validation->set_rules('tanggal', 'Tanggal', 'trim|required');
    $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'trim|required');
    $this->form_validation->set_rules('nominal', 'Nominal', 'trim|required');

    if ($this->form_validation->run() == false) {
      $this->session->set_flashdata('pemasukan', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong>Ubah Data Gagal!</strong> Semua data harus diisi.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        </div>');
      redirect('administrator/pemasukan/index');
    } else {

      $id             = $this->input->POST('id');
      $tanggal        = $this->input->POST('tanggal');
      $deskripsi      = $this->input->POST('deskripsi');
      $nominal        = $this->input->POST('nominal');
      $id_login       = $this->session->userdata('id_login');

      $data = array(
        'tanggal'     => $tanggal,
        'deskripsi'   => $deskripsi,
        'nominal'     => $nominal,
        'id_login'    => $id_login,
      );

      $where = array(
        'id_pemasukan' => $id
      );

      $this->Pemasukan_model->ubah($where, $data, 'tb_pemasukan');
      $this->session->set_flashdata('pemasukan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Data Berhasil Diubah!</strong> Silahkan cek kembali data yang telah anda ubah sesuai atau tidak.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        </div>');
      redirect('administrator/pemasukan/index');
    }
  }

  public function hapus()
  {
    $id         = $this->input->POST('id');
    $where      = array('id_pemasukan' => $id);
    $this->Pemasukan_model->hapus($where, 'tb_pemasukan');
    $this->session->set_flashdata('pemasukan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Data Berhasil Dihapus!</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        </div>');
    redirect('administrator/pemasukan/index');
  }
}
