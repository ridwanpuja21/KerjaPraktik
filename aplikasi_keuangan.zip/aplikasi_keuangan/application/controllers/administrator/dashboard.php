<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		if ($this->session->userdata('username') == null) {
			$this->session->set_flashdata('pesan', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
			<strong>Maaf!</strong> Anda belum Login.
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			</div>');
			redirect('auth');
		}
	}

	public function index()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
		$this->session->set_flashdata('dashboard', null);
		$this->session->set_flashdata('pemasukan', null);
		$this->session->set_flashdata('pengeluaran', null);
		$bulan = 0;
		$tahun = 0;
		$data['pemasukanThn'] = $this->LapPemasukan_model->getTahun();
		$data['pengeluaranThn'] = $this->LapPengeluaran_model->getTahun();
		$data['pemasukan'] = $this->Dashboard_model->jumlah_pemasukan($tahun, $bulan)->result();
		$data['pengeluaran'] = $this->Dashboard_model->jumlah_pengeluaran($tahun, $bulan)->result();
		$data['saldo1'] = $this->Dashboard_model->pemasukan()->result();
		$data['saldo2'] = $this->Dashboard_model->pengeluaran()->result();
		$tittle['title'] = 'Dashboard';
		$this->load->view('templates/header', $tittle);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('administrator/dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function filter()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
		$bulan = $this->input->POST('bulan');
		$tahun = $this->input->POST('tahun');
		$data['pemasukanThn'] = $this->LapPemasukan_model->getTahun();
		$data['pengeluaranThn'] = $this->LapPengeluaran_model->getTahun();
		$data['pemasukan'] = $this->Dashboard_model->jumlah_pemasukan($tahun, $bulan)->result();
		$data['pengeluaran'] = $this->Dashboard_model->jumlah_pengeluaran($tahun, $bulan)->result();
		$data['saldo1'] = $this->Dashboard_model->pemasukan()->result();
		$data['saldo2'] = $this->Dashboard_model->pengeluaran()->result();
		$tittle['title'] = 'Dashboard';
		$this->session->set_flashdata('dashboard', '<div class="alert alert-dark alert-dismissible fade show" role="alert">
        <strong>Silahkan!</strong> ini adalah informasi dari Pemasukan, Pengeluaran, dan Saldo dibulan ' . $bulan . ' tahun ' . $tahun . '.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        </div>');
		$this->load->view('templates/header', $tittle);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('administrator/dashboard', $data);
		$this->load->view('templates/footer');
	}
}
