<?php
defined('BASEPATH') or exit('No direct script access allowed');

class LapMasuk extends CI_Controller
{

  public function __construct()
  {
    parent::__construct();
    if ($this->session->userdata('username') == null) {
      $this->session->set_flashdata('pesan', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
			<strong>Maaf!</strong> Anda belum Login.
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			</div>');
      redirect('auth');
    }
  }

  public function index()
  {
    $data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
    $this->session->set_flashdata('dashboard', null);
    $this->session->set_flashdata('pemasukan', null);
    $this->session->set_flashdata('pengeluaran', null);
    $data['tahun'] = $this->LapPemasukan_model->getTahun();
    $tittle['title'] = 'Laporan Pemasukan';
    $this->load->view('templates/header', $tittle);
    $this->load->view('templates/sidebar', $data);
    $this->load->view('administrator/LapMasuk', $data);
    $this->load->view('templates/footer');
  }

  public function filter()
  {
    $tanggalAwal = $this->input->POST('tanggalAwal');
    $tanggalAkhir = $this->input->POST('tanggalAkhir');
    $tahun1 = $this->input->POST('tahun1');
    $bulanAwal = $this->input->POST('bulanAwal');
    $bulanAkhir = $this->input->POST('bulanAkhir');
    $tahun2 = $this->input->POST('tahun2');
    $nilaifilter = $this->input->POST('nilaifilter');

    if ($nilaifilter == 1) {
      $data['tittle'] = 'Cetak Laporan Pemasukan Per Tanggal';
      $data['subtittle'] = 'Dari tanggal: ' . $tanggalAwal . ' Sampai tanggal: ' . $tanggalAkhir;
      $data['datafilter'] = $this->LapPemasukan_model->filterByTanggal($tanggalAwal, $tanggalAkhir);

      $this->load->view('Administrator/cetak', $data);
    } elseif ($nilaifilter == 2) {
      $data['tittle'] = 'Cetak Laporan Pemasukan Per Bulan';
      $data['subtittle'] = 'Dari bulan: ' . $bulanAwal . ' Sampai bulan: ' . $bulanAkhir . ' Tahun: ' . $tahun1;
      $data['datafilter'] = $this->LapPemasukan_model->filterByBulan($tahun1, $bulanAwal, $bulanAkhir);

      $this->load->view('Administrator/cetak', $data);
    } elseif ($nilaifilter == 3) {
      $data['tittle'] = 'Cetak Laporan Pemasukan Per Tahun';
      $data['subtittle'] = 'Tahun: ' . $tahun2;
      $data['datafilter'] = $this->LapPemasukan_model->filterByTahun($tahun2);

      $this->load->view('Administrator/cetak', $data);
    }
  }
}
