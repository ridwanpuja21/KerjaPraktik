<div class="container-fluid">

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-2">
    <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">Selamat Datang!!</h4>
      <p>Ini adalah tampilan <strong>Cetak Laporan Pemasukan</strong> dari aplikasi keuangan anda, dimana pada menu ini anda dapat mencetak data <strong>Pemasukan</strong> berdasarkan <strong>Tanggal, Bulan,</strong> dan <strong>Tahun.</strong></p>
      <hr>
      <p class="mb-0">Selamat Bekerja.</p>
    </div>
  </div>
  <!-- akhir page heading -->

  <!-- Card Laporan -->
  <div class="row">

    <!-- filter by Tanggal -->
    <div class="col-xl-4 col-md-6 mb-4">
      <div class="card">
        <div class="card-header">
          Cetak Per Tanggal
        </div>
        <div class="card-body">
          <form action="<?php echo base_url() . 'administrator/LapMasuk/filter'; ?>" method="POST" target="_blank">
            <div class="form-group">
              <input type="hidden" name="nilaifilter" value="1">
              <label>Tanggal Awal:</label>
              <input type="date" name="tanggalAwal" required="" class="form-control mb-3">
              <label>Tanggal Akhir:</label>
              <input type="date" name="tanggalAkhir" required="" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Cetak Laporan</button>
          </form>
        </div>
      </div>
    </div>
    <!-- akhir filter by tanggal -->

    <!-- filter by bulan -->
    <div class="col-xl-4 col-md-6 mb-4">
      <div class="card">
        <div class="card-header">
          Cetak Per Bulan
        </div>
        <div class="card-body">
          <form action="<?php echo base_url() . 'administrator/LapMasuk/filter'; ?>" method="POST" target="_blank">
            <div class="form-group">
              <input type="hidden" name="nilaifilter" value="2">
              <label>Pilih Tahun:</label>
              <select class="form-control mb-3" name="tahun1" required="">
                <?php foreach ($tahun as $thn) : ?>
                  <option value="<?php echo $thn->tahun; ?>">
                    <?php echo $thn->tahun; ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <label>Bulan Awal:</label>
              <select class="form-control" name="bulanAwal" required="">
                <option value="1">Januari</option>
                <option value="2">Februari</option>
                <option value="3">Maret</option>
                <option value="4">April</option>
                <option value="5">Mei</option>
                <option value="6">Juni</option>
                <option value="7">Juli</option>
                <option value="8">Agustus</option>
                <option value="9">September</option>
                <option value="10">Oktober</option>
                <option value="11">November</option>
                <option value="12">Desember</option>
              </select>
              <label>Bulan Akhir:</label>
              <select class="form-control" name="bulanAkhir" required="">
                <option value="1">Januari</option>
                <option value="2">Februari</option>
                <option value="3">Maret</option>
                <option value="4">April</option>
                <option value="5">Mei</option>
                <option value="6">Juni</option>
                <option value="7">Juli</option>
                <option value="8">Agustus</option>
                <option value="9">September</option>
                <option value="10">Oktober</option>
                <option value="11">November</option>
                <option value="12">Desember</option>
              </select>
            </div>
            <button type="submit" class="btn btn-primary">Cetak Laporan</button>
          </form>
        </div>
      </div>
    </div>
    <!-- akhir filter by bulan -->

    <!-- filter by tahun -->
    <div class="col-xl-4 col-md-6 mb-4">
      <div class="card">
        <div class="card-header">
          Cetak Per Tahun
        </div>
        <div class="card-body">
          <form action="<?php echo base_url() . 'administrator/LapMasuk/filter'; ?>" method="POST" target="_blank">
            <div class="form-group">
              <input type="hidden" name="nilaifilter" value="3">
              <label>Pilih Tahun:</label>
              <select class="form-control mb-3" name="tahun2" required="">
                <?php foreach ($tahun as $thn) : ?>
                  <option value="<?php echo $thn->tahun; ?>">
                    <?php echo $thn->tahun; ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
            <button type="submit" class="btn btn-primary">Cetak Laporan</button>
          </form>
        </div>
      </div>
    </div>
    <!-- akhir filter by tahun -->

  </div>
  <!-- akhir card laporan -->
</div>