<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-2">
    <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">Selamat Datang <?php echo $user['username']; ?>!!</h4>
      <p>Ini adalah tampilan <strong>Dashboard</strong> dari aplikasi Keuangan anda, dimana pada tampilan ini terdapat informasi tentang <strong>Pemasukan, Pengeluaran,</strong> dan <strong>Saldo</strong> yang anda miliki. Untuk informasi <strong>Pemasukan </strong>dan <strong>Pengeluaran </strong> dapat difilter sesuai dengan tahun dan bulan yang anda inginkan informasinya, dengan cara memilih <strong>Bulan</strong> dan <strong>Tahun</strong> sesuai dengan kebutuhan, lalu klik tombol <strong>Filter.</strong></p>
      <hr>
      <p class="mb-0">Semoga bermanfaat.</p>
    </div>
  </div>

  <?php echo $this->session->flashdata('dashboard'); ?>

  <!-- Awal filter -->
  <form action="<?php echo base_url() . 'administrator/dashboard/filter'; ?>" method="POST" class="form-inline mb-2">
    <label class="sr-only" for="inlineFormInputGroupUsername2">Bulan</label>
    <div class="input-group mb-2 mr-sm-2">
      <select class="form-control" name="bulan">
        <option value="1">Januari</option>
        <option value="2">Februari</option>
        <option value="3">Maret</option>
        <option value="4">April</option>
        <option value="5">Mei</option>
        <option value="6">Juni</option>
        <option value="7">Juli</option>
        <option value="8">Agustus</option>
        <option value="9">September</option>
        <option value="10">Oktober</option>
        <option value="11">November</option>
        <option value="12">Desember</option>
      </select>
    </div>

    <label class="sr-only" for="inlineFormInputGroupUsername2">Tahun</label>
    <div class="input-group mb-2 mr-sm-2">
      <select class="form-control" name="tahun" required="">
        <?php if ($pemasukanThn > $pengeluaranThn) {
          foreach ($pemasukanThn as $pmk) : ?>
            <option value="<?php echo $pmk->tahun; ?>">
              <?php echo $pmk->tahun; ?>
            </option>
          <?php endforeach;
        } else {
          foreach ($pengeluaranThn as $pnl) : ?>
            <option value="<?php echo $pnl->tahun; ?>">
              <?php echo $pnl->tahun; ?>
            </option>
        <?php endforeach;
        } ?>
      </select>
    </div>

    <button type="submit" class="btn btn-primary mb-2">Filter</button>

  </form>
  <!-- Akhir filter -->

  <!-- Content Row -->
  <div class="row">

    <!-- Pemasukan -->
    <div class="col-xl-4 col-md-6 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                Pemasukan</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800">
                Rp.
                <?php foreach ($pemasukan as $pmk) : ?>
                  <?php echo number_format($pmk->total, 0, ',', '.'); ?>
                <?php endforeach; ?>
              </div>
            </div>
            <div class="col-auto">
              <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Akhir Pemasukan -->

    <!-- pengeluaran -->
    <div class="col-xl-4 col-md-6 mb-4">
      <div class="card border-left-danger shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                Pengeluaran</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800">
                Rp.
                <?php foreach ($pengeluaran as $pnl) : ?>
                  <?php echo number_format($pnl->total, 0, ',', '.'); ?>
                <?php endforeach; ?>
              </div>
            </div>
            <div class="col-auto">
              <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Akhir pengeluaran -->

    <!-- saldo -->
    <div class="col-xl-4 col-md-6 mb-4">
      <div class="card border-left-success shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-primary mb-1">
                SALDO (Saat Ini)</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800">
                Rp.

                <?php foreach ($saldo1 as $sld1) : ?>
                <?php endforeach; ?>
                <?php foreach ($saldo2 as $sld2) : ?>
                <?php endforeach; ?>
                <?php $saldo = $sld1->total - $sld2->total; ?>
                <?php echo number_format($saldo, 0, ',', '.'); ?>
              </div>
            </div>
            <div class="col-auto">
              <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Akhir saldo -->

  </div>
</div>