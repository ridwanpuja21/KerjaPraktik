<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <!-- Page Heading -->
  <div class="mb-4">
    <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">Menu Pemasukan</h4>
      <p>Ini adalah tampilan menu <strong>Pemasukan</strong> dari aplikasi keuangan anda. Silahkan <strong>Inputkan </strong>setiap transaksi pembelian produk anda pada menu ini. Pastikan setiap kali <strong>Menginputkan Data</strong> semua kolom diisi dengan data yang sesuai.</p>
      <hr>
      <p class="mb-0">Selamat Bekerja.</p>
    </div>
    <?php echo $this->session->flashdata('pemasukan'); ?>
  </div>


  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3 d-sm-flex align-items-center justify-content-between">
      <h6 class="m-0 font-weight-bold text-primary">Data Pemasukan</h6>

      <button type="button" data-toggle="modal" data-target="#tambahdata" class="btn btn-primary btn-sm"><i class="fas fa-plus-circle mr-2"></i>Tambah Pemasukan</button>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="color: #2E2E2E;">
          <thead>
            <tr class="text-center">
              <th>No.</th>
              <th>Tanggal</th>
              <th>Deskripsi</th>
              <th>Nominal</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $no = 1;
            foreach ($pemasukan as $pmk) : ?>
              <tr>
                <td style="width:30px;" class="text-center"><?php echo $no++ ?></td>
                <td style="width:180px;" class="text-center"><?php echo date('d-m-Y', strtotime($pmk->tanggal)) ?></td>
                <td><?php echo $pmk->deskripsi ?></td>
                <td style="width:180px;">
                  <div class="d-sm-flex align-items-center justify-content-between">
                    <p class="mb-0">Rp.</p>
                    <p class="mb-0"><?php echo number_format($pmk->nominal, 0, ',', '.') ?></p>
                  </div>
                </td>
      </div>
      <td style="width:110px;" class="text-center">
        <!-- tombol ubah -->
        <span type="button" data-toggle="modal" data-target="#editdata<?php echo $pmk->id_pemasukan; ?>" class="badge badge-pill badge-primary">Ubah</span>

        <!-- tombol hapus -->
        <span type="button" data-toggle="modal" data-target="#hapusdata<?php echo $pmk->id_pemasukan; ?>" class="badge badge-pill badge-danger">Hapus</span>

      </td>
      </tr>
    <?php endforeach; ?>
    </tbody>

    </table>
    </div>
  </div>
</div>

<!-- Modal Tambah Data -->
<div class="modal fade" id="tambahdata" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Pemasukan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo base_url() . 'administrator/pemasukan/tambah'; ?>" method="POST">
          <div class="form-group">
            <label>Tanggal</label>
            <input type="date" class="form-control" name="tanggal">
          </div>

          <div class="form-group">
            <label>deskripsi</label>
            <input type="text" class="form-control" placeholder="Masukkan Deskripsi" name="deskripsi">
          </div>
          <div class="form-group">
            <label>Nominal</label>
            <input type="number" class="form-control" placeholder="Masukkan Nominal" name="nominal">
          </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- akhir modal tambah data -->

<!-- Modal Ubah Data -->
<?php
$no = 1;
foreach ($pemasukan as $pmk) : ?>
  <?php $no++; ?>
  <div class="modal fade" id="editdata<?php echo $pmk->id_pemasukan; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ubah Data Pemasukan</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo base_url() . 'administrator/pemasukan/ubah'; ?>" method="POST">
            <div class="form-group">
              <input type="hidden" class="form-control" name="id" value="<?php echo $pmk->id_pemasukan; ?>">
              <label>Tanggal</label>
              <input type="date" class="form-control" name="tanggal" value="<?php echo $pmk->tanggal; ?>">
            </div>

            <div class="form-group">
              <label>deskripsi</label>
              <input type="text" class="form-control" placeholder="Masukkan Deskripsi" name="deskripsi" value="<?php echo $pmk->deskripsi; ?>">
            </div>
            <div class="form-group">
              <label>Nominal</label>
              <input type="number" class="form-control" placeholder="Masukkan Nominal" name="nominal" value="<?php echo $pmk->nominal; ?>">
            </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Ubah</button>
        </div>
        </form>
      </div>
    </div>
  </div>
<?php endforeach; ?>
<!-- akhir modal ubah data -->

<!-- Modal Hapus Data -->
<?php
$no = 1;
foreach ($pemasukan as $pmk) : ?>
  <?php $no++; ?>
  <div class="modal fade" id="hapusdata<?php echo $pmk->id_pemasukan; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Hapus Data Pemasukan</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo base_url() . 'administrator/pemasukan/hapus'; ?>" method="POST">
            <input type="hidden" class="form-control" name="id" value="<?php echo $pmk->id_pemasukan; ?>">
            <p>Apakah anda yakin ingin menghapus data?</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Hapus</button>
        </div>
        </form>
      </div>
    </div>
  </div>
<?php endforeach; ?>
<!-- akhir modal hapus data -->
</div>