<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <!-- Page Heading -->
  <div class="mb-4">
    <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">Menu Pengeluaran</h4>
      <p>Ini adalah tampilan menu <strong>Pengeluaran</strong> dari aplikasi keuangan anda. Silahkan <strong>Inputkan </strong>setiap transaksi pengeluaran yang anda lakukan. Pastikan setiap kali <strong>Menginputkan Data</strong> semua kolom diisi dengan data yang sesuai, serta <strong>Nominal Pengeluaran </strong> yang anda inputkan tidak melebihi <strong>Saldo </strong>yang anda miliki.</p>
      <hr>
      <p class="mb-0">Selamat Bekerja.</p>
    </div>
    <?php echo $this->session->flashdata('pengeluaran'); ?>
  </div>


  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3 d-sm-flex align-items-center justify-content-between">
      <h6 class="m-0 font-weight-bold text-primary">Data Pengeluaran</h6>

      <button type="button" data-toggle="modal" data-target="#tambahdata" class="btn btn-primary btn-sm"><i class="fas fa-plus-circle mr-2"></i>Tambah Pengeluaran</button>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="color: #2E2E2E;">
          <thead>
            <tr class=" text-center">
              <th>No.</th>
              <th>Tanggal</th>
              <th>Deskripsi</th>
              <th>Nominal</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $no = 1;
            foreach ($pengeluaran as $pnl) : ?>
              <tr>
                <td style="width:30px;" class="text-center"><?php echo $no++ ?></td>
                <td style="width:180px;" class="text-center"><?php echo date('d-m-Y', strtotime($pnl->tanggal)) ?></td>
                <td><?php echo $pnl->deskripsi ?></td>
                <td style="width:180px;">
                  <div class="d-sm-flex align-items-center justify-content-between">
                    <p class="mb-0">Rp.</p>
                    <p class="mb-0"><?php echo number_format($pnl->nominal, 0, ',', '.') ?>
                </td>
                </p>
      </div>
      <td style="width:110px;" class="text-center">
        <!-- tombol ubah -->
        <span type="button" data-toggle="modal" data-target="#editdata<?php echo $pnl->id_pengeluaran; ?>" class="badge badge-pill badge-primary">Ubah</span>

        <!-- tombol hapus -->
        <span type="button" data-toggle="modal" data-target="#hapusdata<?php echo $pnl->id_pengeluaran; ?>" class="badge badge-pill badge-danger">Hapus</span>

      </td>
      </tr>
    <?php endforeach; ?>
    </tbody>

    </table>
    </div>
  </div>
</div>

<!-- Modal Tambah Data -->
<div class="modal fade" id="tambahdata" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Pengeluaran</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo base_url() . 'administrator/pengeluaran/tambah'; ?>" method="POST">
          <div class="form-group">
            <label>Tanggal</label>
            <input type="date" class="form-control" name="tanggal">
          </div>

          <div class="form-group">
            <label>deskripsi</label>
            <input type="text" class="form-control" placeholder="Masukkan Deskripsi" name="deskripsi">
          </div>
          <div class="form-group">
            <label>Nominal</label>
            <input type="number" class="form-control" placeholder="Masukkan Nominal" name="nominal">
          </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- akhir modal tambah data -->

<!-- Modal Ubah Data -->
<?php
$no = 1;
foreach ($pengeluaran as $pnl) : ?>
  <?php $no++; ?>
  <div class="modal fade" id="editdata<?php echo $pnl->id_pengeluaran; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ubah Data Pengeluaran</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo base_url() . 'administrator/pengeluaran/ubah'; ?>" method="POST">
            <div class="form-group">
              <input type="hidden" class="form-control" name="id" value="<?php echo $pnl->id_pengeluaran; ?>">
              <input type="hidden" class="form-control" name="tambah" value="<?php echo $pnl->nominal; ?>">
              <label>Tanggal</label>
              <input type="date" class="form-control" name="tanggal" value="<?php echo $pnl->tanggal; ?>">
            </div>

            <div class="form-group">
              <label>deskripsi</label>
              <input type="text" class="form-control" placeholder="Masukkan Deskripsi" name="deskripsi" value="<?php echo $pnl->deskripsi; ?>">
            </div>
            <div class="form-group">
              <label>Nominal</label>
              <input type="number" class="form-control" placeholder="Masukkan Nominal" name="nominal" value="<?php echo $pnl->nominal; ?>">
            </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Ubah</button>
        </div>
        </form>
      </div>
    </div>
  </div>
<?php endforeach; ?>
<!-- akhir modal ubah data -->

<!-- Modal Hapus Data -->
<?php
$no = 1;
foreach ($pengeluaran as $pnl) : ?>
  <?php $no++; ?>
  <div class="modal fade" id="hapusdata<?php echo $pnl->id_pengeluaran; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Hapus Data Pengeluaran</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo base_url() . 'administrator/pengeluaran/hapus'; ?>" method="POST">
            <input type="hidden" class="form-control" name="id" value="<?php echo $pnl->id_pengeluaran; ?>">
            <input type="hidden" class="form-control" name="nominal" value="<?php echo $pnl->nominal; ?>">
            <p>Apakah anda yakin ingin menghapus data?</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Hapus</button>
        </div>
        </form>
      </div>
    </div>
  </div>
<?php endforeach; ?>
<!-- akhir modal hapus data -->
</div>