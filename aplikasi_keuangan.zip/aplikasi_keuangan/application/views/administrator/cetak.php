<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cetak Laporan</title>
  <link href="<?php echo base_url() ?>assets/css/sb-admin-2.css" rel="stylesheet">

  <style>
    .table1,
    th,
    td {
      height: 30px;
      border: 1px solid black;
      border-collapse: collapse;
    }
  </style>
</head>

<body onload="window.print()">
  <div class="container" style="color: #2E2E2E ;">
    <center>
      <h1><?php echo $tittle ?></h1>
      <h5><?php echo $subtittle ?></h5>

      <table class="table1" style="color: #2E2E2E ;">
        <thead>
          <tr class="text-center">
            <th scope="col">No.</th>
            <th scope="col">Tanggal</th>
            <th scope="col">Deskripsi</th>
            <th scope="col">Nominal</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; ?>
          <?php foreach ($datafilter as $row) : ?>
            <tr>
              <td class="text-center" style="width: 50px;"><?php echo $no++; ?></td>
              <td style="width:150px;" class="text-center"><?php echo date('d-m-Y', strtotime($row->tanggal)) ?></td>
              <td class="pl-2" style="width:400px;"><?php echo $row->deskripsi; ?></td>
              <td style="width: 200px;">
                <div class="d-sm-flex align-items-center justify-content-between">
                  <p class="mb-0 pl-2">Rp.</p>
                  <p class="mb-0"><?php echo number_format($row->nominal, 0, ',', '.'); ?></p>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>

          <tr>
            <td class="text-right pr-2" colspan="3"><strong>Jumlah</strong></td>
            <td>
              <?php $total = 0; ?>
              <?php foreach ($datafilter as $row) : ?>
                <?php $total = $total + $row->nominal; ?>
              <?php endforeach; ?>
              <div class="d-sm-flex align-items-center justify-content-between">
                <p class="mb-0 pl-2">Rp.</p>
                <p class="mb-0"><?php echo number_format($total, 0, ',', '.'); ?></p>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </center>
  </div>
</body>

</html>