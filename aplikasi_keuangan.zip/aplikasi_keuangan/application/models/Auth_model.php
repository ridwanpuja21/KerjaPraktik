<?php

class Auth_model extends CI_Model
{
  public function login()
  {
    $username = set_value('username');
  }
}
