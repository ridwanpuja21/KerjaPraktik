<?php

class Pemasukan_model extends CI_Model
{
  public function tampil()
  {
    return $this->db->get('tb_pemasukan');
  }

  public function tambah($data, $table)
  {
    $this->db->insert($table, $data);
  }

  public function ubah($where, $data, $table)
  {
    $this->db->where($where);
    $this->db->update($table, $data);
  }

  public function hapus($where, $table)
  {
    $this->db->where($where);
    $this->db->delete($table);
  }
}
