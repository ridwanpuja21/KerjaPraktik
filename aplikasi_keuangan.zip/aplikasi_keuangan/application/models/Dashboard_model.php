<?php

class Dashboard_model extends CI_Model
{
  public function jumlah_pemasukan($tahun, $bulan)
  {
    return $this->db->query("SELECT SUM(nominal) AS total FROM tb_pemasukan WHERE YEAR(tanggal)='$tahun' AND MONTH(tanggal)='$bulan'");
  }

  public function jumlah_pengeluaran($tahun, $bulan)
  {
    return $this->db->query("SELECT SUM(nominal) AS total FROM tb_pengeluaran WHERE YEAR(tanggal)='$tahun' AND MONTH(tanggal)='$bulan'");
  }

  public function pemasukan()
  {
    return $this->db->query("SELECT SUM(nominal) AS total FROM tb_pemasukan");
  }

  public function pengeluaran()
  {
    return $this->db->query("SELECT SUM(nominal) AS total FROM tb_pengeluaran");
  }
}
