<?php

class LapPengeluaran_model extends CI_Model
{
  function getTahun()
  {
    $query = $this->db->query("SELECT YEAR(tanggal) AS tahun FROM tb_pengeluaran GROUP BY YEAR(tanggal) ORDER BY YEAR(tanggal) ASC");

    return $query->result();
  }

  function filterByTanggal($tanggalAwal, $tanggalAkhir)
  {
    $query = $this->db->query("SELECT * FROM tb_pengeluaran WHERE tanggal BETWEEN '$tanggalAwal' AND '$tanggalAkhir' ORDER BY tanggal ASC");

    return $query->result();
  }

  function filterByBulan($tahun1, $bulanAwal, $bulanAkhir)
  {
    $query = $this->db->query("SELECT * FROM tb_pengeluaran WHERE YEAR(tanggal)='$tahun1' AND MONTH(tanggal) BETWEEN '$bulanAwal' AND '$bulanAkhir' ORDER BY tanggal ASC");

    return $query->result();
  }

  function filterByTahun($tahun2)
  {
    $query = $this->db->query("SELECT * FROM tb_pengeluaran WHERE YEAR(tanggal)='$tahun2' ORDER BY tanggal ASC");

    return $query->result();
  }
}
