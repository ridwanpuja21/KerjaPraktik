<?php

class Pengeluaran_model extends CI_Model
{
  public function tampil()
  {
    return $this->db->get('tb_pengeluaran');
  }

  public function jml1()
  {
    return $this->db->query("SELECT SUM(nominal) AS jml_pemasukan FROM tb_pemasukan");
  }

  public function jml2()
  {
    return $this->db->query("SELECT SUM(nominal) AS jml_pengeluaran FROM tb_pengeluaran");
  }

  public function tambah($data, $table)
  {
    $this->db->insert($table, $data);
  }

  public function ubah($where, $data, $table)
  {
    $this->db->where($where);
    $this->db->update($table, $data);
  }

  public function hapus($where, $table)
  {
    $this->db->where($where);
    $this->db->delete($table);
  }
}
